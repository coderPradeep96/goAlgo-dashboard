# GoAlgo GPT Dashboard

This Streamlit app shows a live dashboard of all GPT roles in the GoAlgo MVP execution phase.

## How to deploy

1. Push this repo to GitHub.
2. Go to [streamlit.io/cloud](https://streamlit.io/cloud)
3. Connect your GitHub, select this repo, and deploy `dashboard.py`.

You'll get a live link like:

```
https://your-username-goalgo-dashboard.streamlit.app
```
